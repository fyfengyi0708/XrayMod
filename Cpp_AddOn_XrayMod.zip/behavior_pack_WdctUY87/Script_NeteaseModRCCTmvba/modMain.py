# -*- coding: utf-8 -*-

from mod.common.mod import Mod


@Mod.Binding(name="Script_NeteaseModRCCTmvba", version="0.0.1")
class Script_NeteaseModRCCTmvba(object):

    def __init__(self):
        pass

    @Mod.InitServer()
    def Script_NeteaseModRCCTmvbaServerInit(self):
        pass

    @Mod.DestroyServer()
    def Script_NeteaseModRCCTmvbaServerDestroy(self):
        pass

    @Mod.InitClient()
    def Script_NeteaseModRCCTmvbaClientInit(self):
        pass

    @Mod.DestroyClient()
    def Script_NeteaseModRCCTmvbaClientDestroy(self):
        pass
